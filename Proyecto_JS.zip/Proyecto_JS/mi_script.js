// Script para mostrar un mensaje interactivo al hacer clic en el botón
document.getElementById("miBoton").addEventListener("click", function() {
    alert("¡Has hecho clic en el botón!");
});
